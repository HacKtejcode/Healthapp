package todoapp.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import todoapp.dao.TodoDAO;
import todoapp.model.Todo;

/**
 * Servlet implementation class UpdateTodo
 */
@WebServlet("/EditTodo")
public class EditTodo extends HttpServlet {
	private static final long serialVersionUID = 1L;
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		res.setContentType("text/html");
		PrintWriter out=res.getWriter();
		
		int bit=0;
		String id=req.getParameter("id");
		String title=req.getParameter("title");
		String descp=req.getParameter("descp");
		String arr[]=req.getParameterValues("status");
		String d=req.getParameter("date");
		Date d1=Date.valueOf(d);
		
		if(arr[0].equals("Completed"))
		{
			bit=1;
		}
		
		HttpSession s=req.getSession(false);
		String username=(String) s.getAttribute("username");
		try
		{
		
//		if(!(title.equals(null)) && !(descp.equals(null)) && !(arr[0].equals(null)) && !(d.equals(null)))
//		{
//			
			TodoDAO t2=new TodoDAO();
			int j=t2.updateTodo(title,descp,bit,d1,Integer.parseInt(id),username);
			if(j==0)
			{
				out.println("<script>alert('Cannot found todo of this id!!!!!! :(')</script>");
				RequestDispatcher rd=req.getRequestDispatcher("operators.html");
				rd.include(req,res);
			}
			else
			{
				out.println("<script>alert('Todo Edited Successfully :) ')</script>");
				RequestDispatcher rd=req.getRequestDispatcher("operators.html");
				rd.include(req,res);
			}
//		else
//		{
//			out.println("<b>Dont leave any fields empty:</b>");
//			RequestDispatcher rd=req.getRequestDispatcher("Edit.html");
//			rd.include(req,res);
//		}
//		
	}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}

