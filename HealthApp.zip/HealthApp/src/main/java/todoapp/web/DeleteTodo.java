package todoapp.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import todoapp.dao.TodoDAO;

/**
 * Servlet implementation class DeleteTodo
 */
@WebServlet("/DeleteTodo")
public class DeleteTodo extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
		res.setContentType("text/html");
		PrintWriter out=res.getWriter();
		
		
		String id=req.getParameter("id");
		HttpSession s=req.getSession(false);
		
		String usname=(String) s.getAttribute("username");
		
		TodoDAO t=new TodoDAO();
		int id1=Integer.parseInt(id);
		int c=t.deleteTodo(usname,id1);
		if(c==0)
		{
			out.println("<script>alert('Cannot found todo of this id!!!!!! :(')</script>");
			RequestDispatcher rd=req.getRequestDispatcher("operators.html");
			rd.include(req, res);
		}
		else
		{
			
			out.println("<script>alert('Todo Deleted Successfully :) ')</script>");
			RequestDispatcher rd=req.getRequestDispatcher("operators.html");
			rd.include(req, res);
		}
		
	}

}
