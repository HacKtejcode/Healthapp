package todoapp.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import todoapp.dao.TodoDAO;
import todoapp.model.Todo;

/**
 * Servlet implementation class TodoController
 */
@WebServlet("/AddTodo")
public class AddTodo extends HttpServlet {
	private static final long serialVersionUID = 1L;
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException, NullPointerException {
		// TODO Auto-generated method stub
		
		res.setContentType("text/html");
		PrintWriter out=res.getWriter();
		int bit=0;
		String title=req.getParameter("title");
		String descp=req.getParameter("descp");
		String arr[]=req.getParameterValues("status");
		String d=req.getParameter("date");
		Date d1=Date.valueOf(d);

		
		if(arr[0].equals("Completed"))
		{
			bit=1;
		}
		
		HttpSession s=req.getSession(false);
		String username=(String) s.getAttribute("username");
		
		
		try {
			if(!(title.equals(null) || (title.equals(""))) && !((descp.equals(null)) || (descp.equals(""))) && !(arr[0].equals(null) || (arr[0].equals(""))) && (d1!=null))
			{
				
				Todo t1=new Todo();
				TodoDAO t2=new TodoDAO();
				
				t1.setTitle(title);
				t1.setDescription(descp);
				t1.setBit(bit);
				t1.setDate(d1);
				t1.setUsername(username);
				
				t2.addTodo(t1);
				out.println("<script>alert('Todo Added Sucessfully :)')</script>");
				RequestDispatcher rd=req.getRequestDispatcher("operators.html");
				rd.include(req,res);
			}
			else
			{
				out.println("<script>alert('Do not leave any fields empty :(')</script></b>");
				RequestDispatcher rd=req.getRequestDispatcher("AddTodo.html");
				rd.include(req,res);
			}
		} catch (NullPointerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch(IllegalArgumentException e)
		{
			e.printStackTrace();
		}
	}
}
