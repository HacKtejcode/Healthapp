package todoapp.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import todoapp.dao.TodoDAO;

/**
 * Servlet implementation class DisplayTodo
 */
@WebServlet("/DisplayTodo")
public class DisplayTodo extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		res.setContentType("text/html");
		PrintWriter out=res.getWriter();
		HttpSession s1=req.getSession(false);
		String us=(String) s1.getAttribute("username");
		

		out.println("<!DOCTYPE html>\r\n"
				+ "<html lang=\"en\">\r\n"
				+ "<head>\r\n"
				+ "	<meta charset=\"UTF-8\">\r\n"
				+ "	<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\r\n"
				+ "<!--===============================================================================================-->	\r\n"
				+ "	<link rel=\"icon\" type=\"image/png\" href=\"images/icons/favicon.ico\"/>\r\n"
				+ "<!--===============================================================================================-->\r\n"
				+ "	<link rel=\"stylesheet\" type=\"text/css\" href=\"vendor/bootstrap/css/bootstrap.min.css\">\r\n"
				+ "<!--===============================================================================================-->\r\n"
				+ "	<link rel=\"stylesheet\" type=\"text/css\" href=\"fonts/font-awesome-4.7.0/css/font-awesome.min.css\">\r\n"
				+ "<!--===============================================================================================-->\r\n"
				+ "	<link rel=\"stylesheet\" type=\"text/css\" href=\"vendor/animate/animate.css\">\r\n"
				+ "<!--===============================================================================================-->\r\n"
				+ "	<link rel=\"stylesheet\" type=\"text/css\" href=\"vendor/select2/select2.min.css\">\r\n"
				+ "<!--===============================================================================================-->\r\n"
				+ "	<link rel=\"stylesheet\" type=\"text/css\" href=\"vendor/perfect-scrollbar/perfect-scrollbar.css\">\r\n"
				+ "<!--===============================================================================================-->\r\n"
				+ "	<link rel=\"stylesheet\" type=\"text/css\" href=\"css1/util.css\">\r\n"
				+ "	<link rel=\"stylesheet\" type=\"text/css\" href=\"css1/main.css\">\r\n"
				+ "<!--===============================================================================================-->\r\n"
				+ "</head>\r\n"
				+ "<body>\r\n"
				+ "	<link rel=\"stylesheet\" href=\"https://unpkg.com/tailwindcss/dist/tailwind.min.css\" />\r\n"
				+ "	<style>\r\n"
				+ "	.gradient {\r\n"
				+ "	  background: linear-gradient(90deg, #d53369 0%, #daae51 100%);\r\n"
				+ "	}\r\n"
				+ "	</style>\r\n"
				+ "	<div class=\"limiter w-full\">\r\n"
				+ "		<div class=\"container-table100\">\r\n"
				+ "			<div class=\"wrap-table100\">\r\n"
				+ "				<div class=\"table100\">\r\n"
				+ "					<table>\r\n"
				+ "						<thead>\r\n"
				+ "							<tr class=\"table100-head\">\r\n"
				+ "								<th class=\"column1\">ID</th>\r\n"
				+ "								<th class=\"column2\">Title</th>\r\n"
				+ "								<th class=\"column3\">Description</th>\r\n"
				+ "								<th class=\"column4\">Status</th>\r\n"
				+ "								<th class=\"column5\">Date</th>\r\n"
				+ "							</tr>");
		
	
		TodoDAO td=new TodoDAO();
	
	
		ResultSet rs=null;
		rs=td.display(us);
		try {
					
			while(rs.next())
			{
			 int id=rs.getInt(1);
			 String description=rs.getString(2);
			 int bit=rs.getInt(3);
			 Date date=rs.getDate(4);
			
			 String title=rs.getString(6);
			 String status;
			 if(bit==0)
			 {
				 status="In Progress";
			 }
			 else
			 {
				 status="Completed";
			 }
			 
			 out.println("</thead>\r\n"
			 		+ "<tbody>\r\n"
			 		+ "<tr>\r\n"
			 		+ "<td>"+id+"</td>\r\n"
			 		+ "<td>"+title+"</td>\r\n"
			 		+ "<td>"+description+"</td>\r\n"
			 		+ "<td>"+status+"</td>\r\n"					
			 		+ "<td>"+date+"</td>\r\n");
			 		
			 		
			 
			 
			 
			 
		 			
			 
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch(NullPointerException e1) {
			e1.printStackTrace();
		}
	out.println("<br><hr></hr>");
	out.println("<form action='operators.html'>"
			+ "<div class=\"flex items-center justify-center\">\r\n"
			+ "        <input type=\"Submit\" class=\"mx-auto lg:mx-0 hover:underline gradient text-white font-bold rounded-full my-6 py-4 px-8 shadow-lg focus:outline-none focus:shadow-outline transform transition hover:scale-105 duration-300 ease-in-out\" value=\"Back\">\r\n"
			+ "        </div>"
			+ "</form>");
		
	}

}
