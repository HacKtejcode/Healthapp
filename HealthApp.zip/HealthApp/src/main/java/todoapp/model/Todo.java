package todoapp.model;

import java.sql.Date;

public class Todo {
	
	private int id;
	private String description;
	private int bit;
	private Date date;
	private String username;
	private String title;
	public Todo() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getBit() {
		return bit;
	}
	public void setBit(int bit) {
		this.bit = bit;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {

		this.date=date;
		
		
		
		
		
//		try {
//			Date d1=new SimpleDateFormat("dd/MM/yyyy").parse(date);
//			this.date =d1.;
//		} catch (ParseException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
	
	
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	

}
