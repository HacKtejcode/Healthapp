package todoapp.dao;

import java.sql.*;

import todoapp.connection.DBConnection;
import todoapp.model.Todo;

public class TodoDAO {
	
	private Connection con;

	public TodoDAO() {
		
		con=DBConnection.getConnection();
	}
	
	public int addTodo(Todo t) throws NullPointerException
	{
		try {
			PreparedStatement p=con.prepareStatement("insert into todo(description,is_done,target_date,username,title) values (?,?,?,?,?)");
			p.setString(1,t.getDescription());
			p.setInt(2,t.getBit());
			p.setDate(3,t.getDate());
			p.setString(4,t.getUsername());
			p.setString(5,t.getTitle());
			return p.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
	}
	
	public ResultSet display(String us)
	{
		
		try
		{
			PreparedStatement pt=con.prepareStatement("select * from todo where username=?");
			pt.setString(1,us);
			ResultSet rs=pt.executeQuery();
			return rs;
		}catch(SQLException e3)
		{
			e3.printStackTrace();
			return null;
		}
	}
	
	public int deleteTodo(String u1,int i)
	{
		try
		{
		PreparedStatement ps=con.prepareStatement("delete from todo where username=? and id=?");
		ps.setString(1,u1);
		ps.setInt(2,i);
		return ps.executeUpdate();
		}catch(SQLException e1)
		{
			e1.printStackTrace();
			return 0;
		}
	}
	

	
	public int updateTodo(String title,String descp,int bit,Date d1,int id4,String unm)
	{
		try
		{
		PreparedStatement ps=con.prepareStatement("update todo set description=?,is_done=?,target_date=?,title=? where id=? and username=?");
		ps.setString(1,descp);
		ps.setInt(2,bit);
		ps.setDate(3,d1);
		ps.setString(4,title);
		ps.setInt(5,id4);
		ps.setString(6,unm);
		
		return ps.executeUpdate();
		}catch(SQLException e1)
		{
			e1.printStackTrace();
			return 0;
		}
	}
	
	
	
	
		
	}

