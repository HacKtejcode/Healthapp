package healthapp.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import healthapp.dao.ClientDAO;
import healthapp.model.Client;




/**
 * Servlet implementation class ClientController
 */
@WebServlet("/ClientController")
public class ClientController extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
 
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		res.setContentType("text/html");
		PrintWriter out=res.getWriter();
	
		  String regexu = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@_$]).+$";
		  String regexp = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@_]).+$";
		  String regexphn="(0|91)?[7-9][0-9]{9}";
		  String regexem = "^[a-zA-Z0-9_+&*-]+(?:\\."+
                  "[a-zA-Z0-9_+&*-]+)*@" +
                  "(?:[a-zA-Z0-9-]+\\.)+[a-z" +
                  "A-Z]{2,7}$";
		String fname=req.getParameter("fname");
		String lname=req.getParameter("lname");
		String ct=req.getParameter("ct");
		String addr=req.getParameter("addr");
		String wt=req.getParameter("wt");
		String ht=req.getParameter("ht");
		String gn[]=req.getParameterValues("gn");
		String un=req.getParameter("un");
		String em=req.getParameter("em");
		String pw=req.getParameter("pw");
		String cf=req.getParameter("cf");
		Pattern p1=Pattern.compile(regexu);
		Pattern p2=Pattern.compile(regexp);
		Pattern p3=Pattern.compile(regexphn);
		Pattern p4=Pattern.compile(regexem);
		
		
		Matcher m1=p1.matcher(un);
		Matcher m2=p2.matcher(pw);
		Matcher m3=p3.matcher(ct);
		Matcher m4=p4.matcher(em);
		
		
		
		if(fname.isEmpty() || lname.isEmpty() || ct.isEmpty() || addr.isEmpty() || wt.isEmpty() || gn[0].isEmpty() || un.isEmpty() || pw.isEmpty() || em.isEmpty() || cf.isEmpty())
		{
			out.println("<script>"+"alert('Dont leave any field empty!!!!!!!!!')"+"</script>");
			RequestDispatcher rd=req.getRequestDispatcher("signup.html");
			rd.include(req,res);
		}
		else if(!(un.length()>4 && un.length()<10) )
		{
			out.println("<script>"+"alert('Username should contain 4 to 10 characters only!!!!!!!!!')"+"</script>");
			RequestDispatcher rd=req.getRequestDispatcher("signup.html");
			rd.include(req,res);
		}
		else if(!m1.matches())
		{
			out.println("<script>"+"alert('Username should atleast have a capital letter, a small letter,a special character(@ or _ or $) and a digit!!!!!!!!!')"+"</script>");
			RequestDispatcher rd=req.getRequestDispatcher("signup.html");
			rd.include(req,res);
		}
		else if(!(pw.length()>4 && pw.length()<10))
		{
			out.println("<script>"+"alert('Password length should be atmost 10!!!!!!')"+"</script>");
			RequestDispatcher rd=req.getRequestDispatcher("signup.html");
			rd.include(req,res);
	}
		else if(!m2.matches())
		{
			out.println("<script>"+"alert('Password should atleast have a capital letter, a small letter,a special character(@ or _ )')"+"</script>");
			RequestDispatcher rd=req.getRequestDispatcher("signup.html");
			rd.include(req,res);
		}
		else if(!(pw.equals(cf)))
		{
			out.println("<script>"+"alert('Password do not match please try again!!!!!!!!!!!!!!!!!')"+"</script>");
			RequestDispatcher rd=req.getRequestDispatcher("signup.html");
			rd.include(req,res);
		}
		else if(!(m3.matches()))
		{
			out.println("<script>"+"alert('Invalid phone number!!!')"+"</script>");
			RequestDispatcher rd=req.getRequestDispatcher("signup.html");
			rd.include(req,res);
		}
		else if(!(m4.matches()))
		{
			out.println("<script>"+"alert('Invalid email entered!!!')"+"</script>");
			RequestDispatcher rd=req.getRequestDispatcher("signup.html");
			rd.include(req,res);
		}
		else
		{
	
			Client c=new Client();
			c.setFirstName(fname);
			c.setLastName(lname);
			c.setContact(ct);
			c.setAddress(addr);
			c.setWeight(wt);
			c.setHeight(ht);
			c.setGender(gn[0]);
			c.setUsername(un);
			c.setPassword(pw);
			c.setEmail(em);
		
			
			
	
		
		try {
			ClientDAO cd=new ClientDAO();
		
			ResultSet rd1=cd.VerifyUsernameDuplicate(c);
		
			rd1.next();
				int	count=rd1.getInt(1);
		if(count!=1)
		{
			int r=cd.addClient(c);
			try
			{
				if(r==1)
				{
					out.println("<font color='white'><h1><b>Registered succesfully</font>");
					out.println("<hr></hr><br><br>");
			
					RequestDispatcher rd=req.getRequestDispatcher("login.html");
					rd.include(req,res);
				}
				else
				{
					out.println("Record are not added succesfully add it again!!!!!!!!");
					RequestDispatcher rd=req.getRequestDispatcher("signup.html");
					rd.include(req,res);
				}
			}catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		else
		{
			out.println("<script>"+"alert('Username already exist please try again!!!!!!!!!!!')"+"</script>");
			RequestDispatcher rd=req.getRequestDispatcher("signup.html");
			rd.include(req,res);
		}
		}catch(Exception e1)
		{
			e1.printStackTrace();
		}
	}
}
}
	
	


