package healthapp.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import healthapp.dao.ClientDAO;
import healthapp.model.Client;

/**
 * Servlet implementation class DeleteController
 */
@WebServlet("/DeleteController")
public class DeleteController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
		res.setContentType("text/html");
		PrintWriter out=res.getWriter();
		HttpSession s=req.getSession(false);
		
		String us=(String)s.getAttribute("username");
		
		ClientDAO c1=new ClientDAO();
		int r=c1.deleteClient(us);
		int r1=c1.deleteCtodo(us);
		int r2=c1.deleteCJournal(us);
		int r3=c1.deleteEscore(us);
		
		if(r!=0 || r1!=0 || r2!=0 || r3!=0)
		{
			out.println("<script>"+"alert('Profile deleted successfully :)')"+"</script>");
			RequestDispatcher rd=req.getRequestDispatcher("profile.html");
			rd.include(req,res);
		}
		else
		{
			out.println("<script>"+"alert('Problem encountered while deleting the profile :(')"+"</script>");
			RequestDispatcher rd=req.getRequestDispatcher("profile.html");
			rd.include(req,res);
		}
	  
			
		
		
	}

}
