package healthapp.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import healthapp.dao.ClientDAO;
import healthapp.model.Client;

/**
 * Servlet implementation class VerifyLogin
 */
@WebServlet("/VerifyLogin")
public class VerifyLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		res.setContentType("text/html");
		PrintWriter out=res.getWriter();
		
		String us=req.getParameter("us");
		String pwd=req.getParameter("pw");
	
		
		Client c1=new Client();
		c1.setUsername(us);
		c1.setPassword(pwd);
		
		ClientDAO c2=new ClientDAO();
		ResultSet rs=c2.verifylogin(c1);
		int count=0;
		try {
			rs.next();
			count=rs.getInt(1);
			if(count!=1)
			{
				out.println("<script>"+"alert('Incorrect username or password entered!!!!!! :(')"+"</script>");
				out.println("<hr></hr><br><br>");
				RequestDispatcher rd=req.getRequestDispatcher("login.html");
				rd.include(req,res);
				
			}
			else
			{
				HttpSession s=req.getSession(true);
				s.setAttribute("username",us);
				out.println("<script>"+"alert('Login successful :)')"+"</script>");
				RequestDispatcher rd=req.getRequestDispatcher("index.html");
				rd.include(req,res);

			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
}
	

		
		
	}

