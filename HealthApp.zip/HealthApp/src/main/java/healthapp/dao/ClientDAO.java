package healthapp.dao;
import healthapp.connection.*;
import healthapp.model.Client;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class ClientDAO {



	private Connection con;

	public ClientDAO() {
		
		con=DBConnection.getConnection();
	}
	
	public int addClient(Client c) {
		try {
		PreparedStatement ps=con.prepareStatement("insert into client (firstname,lastname,contact,address,weight,height,gender,username,password,email) values (?,?,?,?,?,?,?,?,?,?)");
		ps.setString(1,c.getFirstName());
		ps.setString(2,c.getLastName());
		ps.setString(3,c.getContact());
		ps.setString(4,c.getAddress());
		ps.setString(5,c.getWeight());
		ps.setString(6,c.getHeight());
		ps.setString(7,c.getGender());
		ps.setString(8,c.getUsername());
		ps.setString(9,c.getPassword());
		ps.setString(10,c.getEmail());
		return ps.executeUpdate();
		
		
		
		}catch(SQLException e1)
		{
			e1.printStackTrace();
			return 0;
		}
	}
	
	public ResultSet verifylogin(Client e)
	{
		PreparedStatement ps;
		try {
			ps = con.prepareStatement("select count(*) from client where username=? and password=?");
			ps.setString(1,e.getUsername());
			ps.setString(2,e.getPassword());
			ResultSet rs=ps.executeQuery();
			return rs;
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			return null;
		}
		
	}
	
	public ResultSet VerifyUsernameDuplicate(Client e)
	{
		PreparedStatement ps;
		try {
			ps = con.prepareStatement("select count(*) from client where username=?");
			ps.setString(1,e.getUsername());
			ResultSet rs=ps.executeQuery();
			return rs;
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			return null;
		}
	}
	
	public int deleteClient(String us)
	{
		try
		{
		PreparedStatement ps=con.prepareStatement("delete from client where username=?");
		ps.setString(1,us);
		return ps.executeUpdate();
		
		}catch(SQLException e1)
		{
			e1.printStackTrace();
			return 0;
		}
	
		
	}
	
	public int deleteCtodo(String us)
	{
		try
		{
		PreparedStatement ps1=con.prepareStatement("delete from todo where username=?");
		ps1.setString(1,us);
		return ps1.executeUpdate();
		
		

		}catch(SQLException e1)
		{
			e1.printStackTrace();
			return 0;
		}
	
		
	}
	
	public int deleteEscore(String us)
	{
	try
	{
		PreparedStatement ps2=con.prepareStatement("delete from escore where username=?");
		ps2.setString(1,us);
		return ps2.executeUpdate();
	}catch(SQLException e1)
	{
		e1.printStackTrace();
		return 0;
	}

	
	}
	
	
	public int deleteCJournal(String us)
	{
		try
		{
			PreparedStatement ps3=con.prepareStatement("delete from journal where username=?");
			ps3.setString(1,us);
			return ps3.executeUpdate();
			
		

		}catch(SQLException e1)
		{
			e1.printStackTrace();
			return 0;
		}
	
		
	}
	
	
	public int updateClient(Client c1,String us)
	{
		try
		{
		PreparedStatement ps=con.prepareStatement("update client set address=?,contact=?,height=?,weight=?,email=?,password=? where username=?");
		ps.setString(1,c1.getAddress());
		ps.setString(2,c1.getContact());
		ps.setString(3,c1.getHeight());
		ps.setString(4,c1.getWeight());
		ps.setString(5,c1.getEmail());
		ps.setString(6,c1.getPassword());
		ps.setString(7,us);
		
		
		return ps.executeUpdate();
		}catch(SQLException e1)
		{
			e1.printStackTrace();
			return 0;
		}
	}
	
	public ResultSet prevpass(String p,String us)
	{
		PreparedStatement ps;
		try {
			ps = con.prepareStatement("select count(*) from client where username=? and password=?");
			ps.setString(1,us);
			ps.setString(2,p);
			ResultSet rs=ps.executeQuery();
			return rs;
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			return null;
		}
	}


}
	
